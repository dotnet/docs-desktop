﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace xamlcode
{
    class TodoTask
    {
        public string TaskName { get; set; }
        public string Description { get; set; }
        public string Priority { get; set; }

        public override string ToString() => TaskName;
    }
}
