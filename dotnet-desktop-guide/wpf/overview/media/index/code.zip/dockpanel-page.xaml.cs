﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace xamlcode
{
    /// <summary>
    /// Interaction logic for dockpanel_page.xaml
    /// </summary>
    public partial class dockpanel_page : Window
    {
        public dockpanel_page()
        {
            InitializeComponent();
        }
    }
}
